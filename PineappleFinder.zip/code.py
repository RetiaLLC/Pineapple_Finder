import random
import time
import wifi
import board
import busio
import displayio
import adafruit_displayio_sh1106

import neopixel
import terminalio
from adafruit_display_text import label

def display_attack_detected():
    group = displayio.Group()
    text_area = label.Label(terminalio.FONT, text="\n KARMA ATTACK!\n WIFI HACKING SPOTTED\n EVIL NETWORKS FOUND\n\n", color=0xFFFF00)
    group.append(text_area)
    display.show(group)
    np.fill((255, 0, 0))
    np.write()

displayio.release_displays() # Initialize the display
WIDTH = 130
HEIGHT = 64
i2c = busio.I2C(board.SCL, board.SDA)
display_bus = displayio.I2CDisplay(i2c, device_address=0x3c)
display = adafruit_displayio_sh1106.SH1106(display_bus, width=WIDTH, height=HEIGHT)

uwu_wifi_names = ["RainbowUnicornLand", "EvilNetworkTime",] # ... (include all 50 names)
wifi.radio.enabled = True
print("WiFi radio enabled.")
base_ssid = random.choice(uwu_wifi_names)
print(f"Selected base SSID: {base_ssid}")

np = neopixel.NeoPixel(board.IO12, 1, auto_write=True)
np.fill((0, 20, 0))

while True:
    ssid = base_ssid + str(random.randint(100, 999))
    print(f"Trying SSID: {ssid}")
    for attempt in range(10):
        try:
            print(f"Attempt {attempt+1} connecting to:\n{ssid}")
            wifi.radio.connect(ssid, timeout=0.1)
        except ConnectionError:
            print(f"Connection to {ssid} failed on attempt {attempt+1}")
        if wifi.radio.ipv4_address:
            print("Attack detected!")
            display_attack_detected()
            time.sleep(15)
            np.fill((0, 255, 0))
